public class Add_Workout {

    public exercise addExercise(type, duration) {

        //TODO Replace with actual algorithm
        return new_exercise;

    }

    public string addComment(input) {

        //TODO Replace with actual algorithm
        return comment;

    }

    public void submitWorkout(exercises[], string comment) {

        //TODO Replace with actual algorithm

    }



}
