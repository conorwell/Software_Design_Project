public class Create_Profile {
    private user passwordHash(password, user) {

        //TODO Replace with actual algorithm
        return user;
    }

}
