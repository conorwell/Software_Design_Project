public class Edit_Profile {
    public String changeUsername(password,user) {

        //TODO Replace with actual algorithm
        return new_username;

    }

    public String changePassword(password,user) {

        //TODO Replace with actual algorithm
        return new_password;

    }

}
