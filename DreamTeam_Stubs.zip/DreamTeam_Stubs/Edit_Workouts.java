public class Edit_Workouts {
    public exercise editExercise() {

        //TODO Replace with actual algorithm
        return updated;

    }

    public string editComment() {

        //TODO Replace with actual algorithm
        return updated;

    }

    public void submitWorkout() {

        //TODO Replace with actual algorithm

    }


}
