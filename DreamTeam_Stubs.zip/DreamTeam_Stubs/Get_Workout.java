public class Get_Workout {
    public exercise[] getExercises() {

        //TODO Replace with actual algorithm
        return exercise_list;

    }


}
