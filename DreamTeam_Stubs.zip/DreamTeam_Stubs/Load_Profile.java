public class Load_Profile {

    private String readfromProfileCSV(password, user) {

        //TODO Replace with actual algorithm
        return user_profile;

    }

}
