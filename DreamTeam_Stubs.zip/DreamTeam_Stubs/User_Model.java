public class User_Model {
    private void writetoProfileCSV(password, user) {

        //TODO Replace with actual algorithm
    }
    private array getUsers() {

        //TODO Replace with actual algorithm
        return users_array;
    }

    private void addUser(password,user) {

        //TODO Replace with actual algorithm

    }

    private void editUser(password,user) {

        //TODO Replace with actual algorithm

    }


}
