public class View_Friends {

    public void addFriend(user) {

        //TODO Replace with actual algorithm

    }

    public string searchFriend(user_input) {

        //TODO Replace with actual algorithm
        return user_matches;

    }

}
