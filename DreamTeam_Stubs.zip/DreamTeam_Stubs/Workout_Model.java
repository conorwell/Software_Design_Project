public class Workout_Model {
    public workouts[] getWorkouts() {

        //TODO Replace with actual algorithm
        return workouts_list;

    }

    public void addWorkouts() {

        //TODO Replace with actual algorithm

    }


}
